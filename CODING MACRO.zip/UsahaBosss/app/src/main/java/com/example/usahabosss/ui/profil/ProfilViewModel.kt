package com.example.usahabosss.ui.profil

import androidx.lifecycle.ViewModel

class ProfilViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}