package com.example.usahabosss.ui.search

import androidx.lifecycle.ViewModel

class SearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}