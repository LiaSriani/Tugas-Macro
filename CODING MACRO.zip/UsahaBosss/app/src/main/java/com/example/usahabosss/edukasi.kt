package com.example.usahabosss

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class edukasi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edukasi)
    }
    fun textView(view: View) {
        val intent = Intent(this@edukasi, MainEdukasi::class.java)
        startActivity(intent)
    }
}